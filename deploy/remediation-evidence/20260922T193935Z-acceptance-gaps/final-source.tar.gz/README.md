# Agentcraft

Framework for building end-to-end agentic applications. Investigation's runtime dependencies
belong in libraries; other capabilities and workflow guidance belong in skills.
Start with [documentation](docs/README.md); use the
[workspace guide](libraries/README.md) for installation and the canonical catalogue.

Investigation's latest completed split acceptance is listed below. Subsequent
[generic reuse migrations](template_apps/investigation_app/docs/LIBRARY_MIGRATION.md#generic-reuse-audit)
are source-implemented; integrated backend/browser checks and discovery regeneration remain pending.
Other application and cloud statements remain dated records, not fresh live checks.

The Hillclimber writeup app moved on 2026-09-18 to
`/home/hanchoong/han-ops-center/agentcraft_doc app`, including its Vocs site, bundled demo,
dataset example, active deployment tooling and release receipts. Quote the path's space.
Local site and demo production builds pass at the destination. `rg-singtel-ticket-poc` and its contained
resources were deleted and independently verified absent on 2026-09-16.
The original source remains available. The [live writeup](https://ca-agentcraft-writeup.wonderfulmoss-6cbdac9f.eastus2.azurecontainerapps.io)
now runs by itself in `rg-agentcraft-testing`, `eastus2`, with only its required hosting resources.
[Deployment details](deploy/README.md#writeup-deployment) own configuration, read-back and
desktop/mobile browser evidence. Corporate sign-in remains required; interactive sign-in and
first-use consent are not yet verified.

The [Content Understanding recipe](.github/skills/azure-content-understanding/SKILL.md)
owns native async Microsoft SDK extraction, its uv manifest/lock, contracts,
tests and recorded report outputs. The [datacrafting testbed](testbeds/datacrafting/README.md)
now has an [independently reviewed Operations v3 dataset](testbeds/datacrafting/operations-crafting/REVIEW.md):
14 detection and 8 conditional-action cases with 75,908 synthetic SCADA rows and
322 alarms. More than twice the v2 counts were added as visible noise per case.
154 tests and persisted replay pass; this validates the synthetic process, not
training robustness or real telemetry integration. The extra Function wrapper remains removed.
Source PDFs and CU outputs remain intact. No new cloud calls or teardown occurred;
[historical deployment and cleanup records](testbeds/datacrafting/deploy/README.md) identify
the last observed resources, including the CU service and retired DI account. Diagram
semantics, current cloud liveness and exact cost remain unverified.

The [Foundry Hosted Agents experiment](testbeds/foundry-hosted-agents/README.md)
and evaluation migration now have [append-only acceptance-gap evidence](deploy/remediation-evidence/20260922T193935Z-acceptance-gaps/README.md):
two actual builds overlapped 43.349496 seconds with exact direct associations;
fresh E targets final migration H v3, three finite rows and oracle 3/3.
H41 tests pass; unchanged E26/O46 evidence reused. F07 corrected to three uv
installation sites; same-scope lines 3501 -> 3523 -> 4291 at review -> 4372 now.
Final H/O deployments and historical results remain unchanged. F09 publication pending.

The historical [Foundry Hosted Agents experiment](testbeds/foundry-hosted-agents/README.md)
passed two-version live acceptance: baseline version 2 calls `nonce_digest`,
version 3 adds and calls `nonce_statistics`; both have correlated tool evidence,
stored-response readback and anonymous denial. Twenty-one local tests pass.
Hosted agent, images and scoped pull grant remain retained; cost is unmeasured.

The [Foundry evaluation testbed](testbeds/foundry-agent-evaluation/README.md)
completed one three-row cloud evaluation against unchanged hosted version 3:
coherence scores 4, 4, 2; independent deterministic proof 3/3. Eighteen tests pass.
One registered dataset/version, one definition and one completed run are retained,
along with diagnosed storage/version failures and one orphan uploaded blob.
Reusable operator skill and verified closeout record exact contracts and recovery.
No optimization or quality-improvement claim; cost and reservation lifetime unknown.

The separate [Foundry optimization testbed](testbeds/foundry-agent%20optimization/README.md)
retains a verified prechange snapshot, frozen classification scorer/constitution,
licensed UCI Iris data and disjoint 87/30/30 train/validation/holdout splits.
Separate hosted classifier baseline scores accuracy/macro-F1 0.933333 on all 30
validation rows. Native evaluator and loader canaries pass; real SDK optimizer job
returned two generated candidates, both below the native baseline in independent
validation. Native-generated candidate `_0001` now runs as demonstration v6 with
verified loaded config/image, authenticated responses, stored readback and anonymous
401. Capability victory: native optimization produced changed configuration actually
hosted, with all candidate metrics retained. Validation regressed: 28/30 versus
baseline 29/30; no improvement, generalization or production-promotion claim.
Baseline v5 remains restore target; its historical baseline/same-config holdout each
scored 30/30. Generated demonstration candidate holdout: not evaluated.

## Agent Team

Local [agent coordination](.github/agents/README.md) uses `general-overseer` as the normal user contact,
`general-orchestrator` for one verifiable increment at a time, and optional specialists. Teams return
evidence before follow-on work is commissioned. Shared skills and safety authorities remain active.

[AgentCraft Overseer v1.64](.github/agents/agentcraft-overseer.agent.md) specializes this team for
data-understanding-first, measured solution improvement, with strict brevity, a validated project constitution
with explicit modification levers. Direct children are exactly [agentcraft-orchestrator](.github/agents/agentcraft-orchestrator.agent.md),
and advisory-only
[mock oracle](.github/agents/agentcraft-oracle.agent.md), optionally consulted by either AgentCraft caller.
Domain orchestrator owns assigned stages/iterations
and pilots all candidates/specialists; overseer owns mission alignment, strategic priorities, authorization/criteria
changes and evidence review. No direct test-subject exception. Definition/preflight checks only;
native client activation and live mission behavior are not certified by those checks.
The overseer directly publishes and verifies the process's version/timestamp JSON record
bundles, exact constitution/source snapshots and verified decision-to-outcome references. The overseer
retains decisions and directly maintains lessons. Both orchestrators are prohibited from dispatching any
overseer, including via nested/CLI/alias routes. Isolated overseer evaluation is unsupported.
The retired local test-subject definition is removed; historical invocations remain evidence, not routing authority.
Source edits do not reconfigure loaded sessions. Total automatic capture and tested live reversion are not implied.
Both AgentCraft roles require recorded starts, periodic elapsed-time checks and explicit-user-deadline
penalty accounting through the existing timing tool; host scheduling and compliance remain unverified.

## Current Foundation

The [8-member uv workspace](libraries/README.md#current-state) sits within ten retained
Investigation-used library directories, alongside four npm packages.
Native async `azdata` owns data access and
`llm_interface` is the single model/agent engine. Investigation composes these public
owners; raw-model compatibility and synchronous adapters are retired, not providers.

The skill-owned [framework](.github/skills/harness-guide/framework/README.md) provides description, catalogue lookup,
explicit bindings and an opt-in offline MCP host. Its callable composed example runs
synthetic native HTTP data/rules/model work with real filesystem recovery. Source checks
and artifact identities are distinguished in the historical [release receipt](.github/skills/harness-guide/framework/distribution/release-candidate.json).
Eleven unused library owners moved into skills; twelve duplicate skill directories are removed.
[Library scope](libraries/README.md#library-scope) records retained owners and moved guidance.
[capabilities.json](libraries/capabilities.json) owns generated discovery.
The duplicated in-checkout portable plugin tree is removed; the
[workspace guide](libraries/README.md#discovery-and-mcp) owns source-only discovery
and explicit self-contained external exports. Regeneration and post-reuse local Investigation
acceptance pass; no whole-project size or RAM improvement is established.

[Agent optimization](.github/skills/agent-optimization/SKILL.md) implements local frozen-cohort
evaluation, immutable generations, evidence and persisted replay. Its research collection
is separate: model-quality improvements, live evaluation and cloud observability are not
established by local runtime or synthetic tests. Separate Foundry preparation does not
establish this library's live acceptance.

The [overseer self-optimization demonstration](demonstration_project/README.md) has an authorized
local data-understanding constitution and historical `local-dev-test-subject` invocations. Two recorded
exploratory iterations reproduced CSV-prefix observations and corrected a label-extraction tool gap.
Historical revision-7 discovery repeats bounded CSV/Parquet surveys, records development membership and
proposed splits, and exposes prefix bias, duplicate leakage and timestamp disagreement. Fresh candidate
dispatch for this checkpoint is blocked by unavailable host tools; outcome archival remains pending.
Scored comparison, independent evaluation and performance gains remain unverified; unknown data
properties and targets are active discovery work, not permission blockers.
Revision 8 starts a separate, incomparable `public-investigation-20260920` exploration series.
The [local public-data package](template_apps/investigation_app/deploy/README.md#public-data-local-package)
now contains a pinned Splunk emulation case, derived alarm, two events, same-source graph and official
MITRE v18 advisory documents. Raw inputs remain ignored; no private data, Azure writes or model calls.
Revision 9 wires an explicit public Cosmos profile into production services, routes, tools and a
case-to-source UI board. Source-aware scanner/chat and protected signed identity now pass the
[local public acceptance](template_apps/investigation_app/deploy/README.md#public-integration-checkpoint):
desktop/mobile drilldown, actual scan control and scripted native SDK tools. The authorized
[public deployment](deploy/README.md#public-investigation-deployment) now runs in `rg-agentcraft-dev`:
real Cosmos/Gremlin/Search ingestion and idempotent readback, signed desktop/mobile workflows,
native model tools, durable owner/CAS profiles/authoring and replay refusal across replica restart
pass. Human interactive sign-in, exact costs, full-dataset acceptance and comparative gain remain unverified.
HIKARI-2021 and UWF-ZeekData22 tables are acquired with a scripted, hash-verified download sequence;
payloads are Git-ignored. Cyber detection quality and held-out evaluation remain unverified.
The former Optimization Framework is retained intact as a Git-ignored local reference beneath
that project, not an active runtime. Its historical partial results do not establish arbitrary
code execution, independent comparison, full Investigation acceptance or production cloud proof.

## Recorded Checks

The historical [conformance record](.github/skills/harness-guide/framework/CONFORMANCE.md) separates returned source
checks, dated artifacts, native-client acceptance and unverified live/platform requirements.
Counts from overlapping commands are not a single portfolio total.

- [Investigation reuse acceptance](template_apps/investigation_app/docs/LIBRARY_MIGRATION.md#verification-boundary):
  610 backend/deploy tests, 29 frontend tests, production build and 43 signed native-browser
  checks passed. Live acceptance: 23 API checks, 72 scanner/catalogue checks, 40 Investigation
  checks and 24 Agent Editor checks; results and saved versions read back. Local source
  acceptance does not recertify historical release artifacts or guarantee model outputs.
- [Native client closeout](.github/skills/harness-guide/framework/distribution/native-client-closeout.json) and
  [guidance deduplication](.github/skills/harness-guide/framework/distribution/guidance-dedup.json): historical CLI
  installation, discovery, disable and cleanup. Upstream malformed-manifest acceptance remains
  documented separately from mandatory first-party validation.
- [Release receipt](.github/skills/harness-guide/framework/distribution/release-candidate.json) and
  [independent reader](.github/skills/harness-guide/framework/distribution/independent-reader.json): recorded
  offline installation, repeated results, refusal recovery and cleanup. Later source/text
  changes are recorded by the historical [Investigation closeout](.github/skills/harness-guide/framework/distribution/investigation-closeout.json);
  no publication is implied.

[Measured simplification](template_apps/investigation_app/docs/LIBRARY_MIGRATION.md#closeout-reduction):
original runtime/config scope 190 -> 114 files and 29,046 -> 15,539 lines. This closeout
removes two runtime files/171 lines, plus 305 generated mirror and 191 build/cache files.
Expanded end-to-end tests increase total app bytes; no whole-project size, RAM or latency
improvement is inferred from unrelated active data changes.

Historical Perth, Cosmos and MITRE observations remain labeled in the migration record.
Custom Optimizer received only five approved dependency/path edits; it was not executed
or otherwise modified. Existing changes remain intact.

## Retained Cloud Records

Perth ADX is Running with idle auto-stop disabled through its existing deployment owner.
Continuous compute charges apply; manual stops, external schedules and outages are not prevented.

A dedicated Azure resource group for future connector E2E tests was created and observed empty
on 2026-09-14. The [deployment runbook](deploy/README.md) owns its non-secret targets, verification evidence and protected lifecycle commands.
Service provisioning, sample data and live CRUD tests remain deferred.

## Pending Acceptance

- Beyond Investigation's authorized existing targets, live provider acceptance still needs
  explicit targets, identities and data-processing/inference authority. Investigation's
  [local request-count quota is removed](template_apps/investigation_app/deploy/README.md#current-scope);
  native per-run limits remain. Offline fixtures do not establish broader provider acceptance.
- [Azure access guidance](libraries/entra-auth/docs/skills/azure-access-management.md) owns native-first
  identity workflows. Investigation's frontend sign-in migration is not started; preserve
  tenant/record authorization, cookies/CSRF, session expiry/revocation and signed-agent
  refusals until separate deployed acceptance passes. Auth configuration is unchanged here.
- [Data verification](libraries/azure-data-connectors/VERIFICATION.md) and
  [model validation](libraries/llm-interface/VALIDATION.md) retain provider, dependency,
  platform and load limitations. App/library source passes are not whole-system acceptance.
- Genuine pinned ontology inputs were found outside the checkout and tested read-only;
  they are no longer a missing-input blocker. Deployed lifecycle, additional platform/
  dependency floors and complete static typing remain unverified; typing markers are partial.
- Independent-reader evidence covers its recorded three offline tasks, not a fresh run
  of this documentation revision. Native plugin installation is verified separately.
  Comparative effort, memory, latency and model-quality gains are not claimed.

## Limits

- Live cloud access, paid model calls and deployments require operator configuration and authorization.
- Installation and guidance do not enable MCP, authenticate callers or authorize tools.
- Final artifact acceptance and publication are separate; no public registry availability is claimed.
- New contributions, datasets and third-party assets need their own provenance and rights review.

The [MIT license](LICENSE) covers repository-authored code. Bundled fonts and artwork retain their
separate notices; external runtime dependencies retain their own terms. Review the
[release contract](libraries/README.md#release-contract) before publishing a derived package.

## Contributing

This project welcomes contributions and suggestions.  Most contributions require you to agree to a
Contributor License Agreement (CLA) declaring that you have the right to, and actually do, grant us
the rights to use your contribution. For details, visit [Contributor License Agreements](https://cla.opensource.microsoft.com).

When you submit a pull request, a CLA bot will automatically determine whether you need to provide
a CLA and decorate the PR appropriately (e.g., status check, comment). Simply follow the instructions
provided by the bot. You will only need to do this once across all repos using our CLA.

This project has adopted the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/).
For more information see the [Code of Conduct FAQ](https://opensource.microsoft.com/codeofconduct/faq/) or
contact [opencode@microsoft.com](mailto:opencode@microsoft.com) with any additional questions or comments.

## Trademarks

This project may contain trademarks or logos for projects, products, or services. Authorized use of Microsoft
trademarks or logos is subject to and must follow
[Microsoft's Trademark & Brand Guidelines](https://www.microsoft.com/legal/intellectualproperty/trademarks/usage/general).
Use of Microsoft trademarks or logos in modified versions of this project must not cause confusion or imply Microsoft sponsorship.
Any use of third-party trademarks or logos are subject to those third-party's policies.
