"""FastAPI composition root for the CyberEye application.

Nothing is defined here that a route could own. This module builds the application,
installs the access edge, composes the services every router reads from `app.state`,
and mounts the built frontend.
"""

from __future__ import annotations

import asyncio
from contextlib import AsyncExitStack, asynccontextmanager
from pathlib import Path
from urllib.parse import urlsplit

from azdata import ConnectorConfig, Limits, Policy, ResourceAddress
from azure.identity.aio import DefaultAzureCredential
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from resource_explorer import SELECTION_HEADER, build_inventory_router

from .agents import AgentService, load_agent_spec
from .agents.editor import AgentEditor
from .agents.profiles import SuspectProfiles
from .agents.cosmos_state import CosmosOwnerDocuments
from .api import ROUTERS
from .api.dependencies import inventory_service
from .config import settings
from .data import GraphService, ReadOnlyAdx
from .data.graph_binding import bind_graph
from .data.telemetry import CosmosTelemetry
from .data.public_graph import PublicGraphService
from .inventory import build_service as build_inventory_service
from .inventory import default_probes
from .inventory.manifest import load_registry
from .investigation import Scanner, load_configuration
from .knowledge import search as knowledge_search
from .models import ScanResponse
from .security import OwnedCache, SessionStore, install_security
from .security.entra import OwnerAccessGuard


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings.validate()
    agent_spec = load_agent_spec()
    async with DefaultAzureCredential(exclude_interactive_browser_credential=True) as credential:
        public = settings.telemetry_profile == "public-cosmos"
        manifest = settings.public_manifest() if public else None
        adx = (CosmosTelemetry(endpoint=settings.cosmos_endpoint, database=settings.cosmos_database,
            container=settings.cosmos_container, partition=manifest["partition"], source=manifest["source"],
            credential=credential, max_rows=min(settings.max_rows, 200)) if public else ReadOnlyAdx(credential=credential))
        knowledge = None
        graph = None
        agent = None
        probes = {}
        state_stores = []
        try:
            if public:
                for namespace in ("agents", "profiles"):
                    state_stores.append(CosmosOwnerDocuments(endpoint=settings.cosmos_endpoint,
                        database=settings.cosmos_database, container=settings.state_container,
                        namespace=namespace,
                        credential_factory=lambda: DefaultAzureCredential(exclude_interactive_browser_credential=True)))
            search_config = (ConnectorConfig(settings.search_endpoint,
                             ResourceAddress({"index": settings.knowledge_index}),
                             (urlsplit(settings.search_endpoint).hostname or "",))
                             if settings.search_endpoint and settings.knowledge_index else None)
            knowledge = await knowledge_search.configure(search_config, credential=credential,
                policy=Policy("investigation-knowledge", grants={"query", "read"}, max_concurrency=1,
                              limits=Limits(timeout_seconds=30, max_items=100,
                                            max_output_bytes=1_048_576, max_attempts=1)))
            app.state.knowledge = knowledge
            graph_connector = bind_graph(account=settings.graph_account,
                database=settings.graph_database, graph=settings.graph_name,
                subscription=settings.graph_subscription_id, resource_group=settings.graph_resource_group,
                credential=credential, readonly_key_value=settings.graph_readonly_key,
                require_injected_key=public)
            graph_coordinates = {"account": settings.graph_account, "database": settings.graph_database,
                                 "graph": settings.graph_name, "connector": graph_connector}
            graph = (PublicGraphService(telemetry=adx, **graph_coordinates) if public
                     else GraphService(**graph_coordinates))
            app.state.graph = graph
            probes = default_probes(credential_provider=lambda: credential,
                public_telemetry=adx if public else None, public_graph=graph if public else None)
            app.state.inventory_probes = probes
            scanner = Scanner(adx, None if public else load_configuration(Path(settings.detector_config_path)))
            app.state.adx = adx
            app.state.scanner = scanner
            app.state.profiles = SuspectProfiles(Path(settings.agent_store_dir).parent / "suspect-profiles.sqlite3",
                                                storage=state_stores[1] if public else None)
            agent = AgentService(adx, scanner, agent_spec, identity=credential,
                                 allow_model_calls=settings.allow_model_calls, profiles=app.state.profiles, graph=graph)
            app.state.agent = agent
            app.state.agent_editor = AgentEditor(Path(settings.agent_store_dir), agent_spec, settings.agent_models,
                                                storage=state_stores[0] if public else None)
            registry = None
            if public:
                registry = load_registry(settings.app_root / "control/public_data_inventory.yaml", env={
                    "CYBEREYE_COSMOS_ENDPOINT": settings.cosmos_endpoint,
                    "CYBEREYE_COSMOS_DATABASE": settings.cosmos_database,
                    "CYBEREYE_COSMOS_CONTAINER": settings.cosmos_container,
                    "CYBEREYE_PUBLIC_PARTITION": manifest["partition"],
                    "GREMLIN_ACCOUNT": settings.graph_account, "GREMLIN_DATABASE": settings.graph_database,
                    "GREMLIN_GRAPH": settings.graph_name, "CYBEREYE_SEARCH_ENDPOINT": settings.search_endpoint,
                    "CYBEREYE_MITRE_SEARCH_INDEX": settings.knowledge_index})
            app.state.inventory = build_inventory_service(registry, probes=probes)
            app.state.sessions = SessionStore()
            app.state.last_scan = OwnedCache[ScanResponse]()
            yield
        finally:
            async with AsyncExitStack() as cleanup:
                for state_store in state_stores:
                    cleanup.push_async_callback(asyncio.to_thread, state_store.close)
                cleanup.push_async_callback(adx.aclose)
                if agent is not None:
                    cleanup.push_async_callback(agent.aclose)
                if graph is not None:
                    cleanup.push_async_callback(graph.aclose)
                if knowledge is not None:
                    cleanup.push_async_callback(knowledge_search.reset_client)
                for name in ("adx", "cosmos", "search", "gremlin"):
                    if name in probes:
                        cleanup.push_async_callback(probes[name].aclose)


app = FastAPI(
    title="CyberEye Local",
    version="1.0.0",
    description="Historical replay scanner, evidence board, and ADX-equipped investigation agent.",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=list(settings.cors_origins),
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT"],
    allow_headers=["Content-Type", "Accept", SELECTION_HEADER],
)

# Added last, so it runs first: Starlette builds the stack in reverse registration order. The
# gate refuses every unauthenticated request before routing, before body parsing and before
# the static mount, and signed developer access sits outside it because it produces the
# principal the gate reads. Both are unconditional edges; only the signing key is optional,
# and without it no signed authorizing path exists at all.
if settings.telemetry_profile == "public-cosmos":
    app.add_middleware(OwnerAccessGuard, allowed_principals=settings.allowed_principal_ids)
security = install_security(app)

# The inventory is a component contribution: a bounded, read-only router over a
# registry this application composes. Its own auth, static mounts and settings
# are deliberately not adopted — this application already owns all three.
app.include_router(build_inventory_router(inventory_service))

for _router in ROUTERS:
    app.include_router(_router)

FRONTEND_DIST = settings.app_root / "frontend" / "dist"
if FRONTEND_DIST.is_dir():
    app.mount("/", StaticFiles(directory=FRONTEND_DIST, html=True), name="frontend")
