"""CyberEye local backend."""
