from __future__ import annotations

import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
import hashlib
import json
import logging
import os
from pathlib import Path
import uuid


def state_probe():
    from agentconfig import AgentDraft, AgentStoreError, AgentVersionStore, AssignAgent, SaveAgent
    from azure.identity.aio import DefaultAzureCredential
    from app.cybereye.backend.agents.cosmos_state import CosmosOwnerDocuments

    owner = "deployment-probe:" + uuid.uuid4().hex
    def storage():
        return CosmosOwnerDocuments(endpoint=os.environ["CYBEREYE_COSMOS_ENDPOINT"],
            database=os.environ["CYBEREYE_COSMOS_DATABASE"], container=os.environ["CYBEREYE_STATE_CONTAINER"],
            namespace="agents", credential_factory=lambda: DefaultAzureCredential(exclude_interactive_browser_credential=True))
    def store(backend):
        return AgentVersionStore(Path("/state/probe"), builtin_id="probe_builtin",
            builtin=AgentDraft(name="Probe", model="probe", system_prompt="Deployment verification only"),
            validate=lambda draft: None, validate_assignment=lambda draft: None, storage=backend)
    backend = storage()
    try:
        first = store(backend)
        request = SaveAgent(name="Probe", model="probe", system_prompt="Deployment verification only")
        saved = first.save(owner, request)
        assigned = first.assign(owner, AssignAgent(agent_id=saved.agent_id, version=1, expected_revision=0))
    finally:
        backend.close()
    left, right = storage(), storage()
    try:
        first, second = store(left), store(right)
        assert first.get(owner, saved.agent_id) == saved
        assert first.assignment(owner) == assigned
        try:
            second.get(owner + ":foreign", saved.agent_id)
        except AgentStoreError as error:
            assert error.status == 404
        else:
            raise AssertionError("foreign_owner_accepted")
        def save(current):
            try:
                return current.save(owner, request.model_copy(update={"base_version": 1, "expected_latest_version": 1}), saved.agent_id).version
            except AgentStoreError as error:
                return error.status
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(save, (first, second)))
        assert sorted(results) == [2, 409]
        assert second.get(owner, saved.agent_id, 1) == saved
        assert second.assignment(owner) == assigned
        return {"restart_instances": True, "owner_refusal": True, "concurrent_results": sorted(results),
                "immutable_version": True, "assignment_pinned": True,
                "retained_probe_owner_sha256": hashlib.sha256(owner.encode()).hexdigest()}
    finally:
        left.close()
        right.close()


async def table_probe():
    from entra_auth import AzureTableRecordStore, SessionService, new_flow
    from signed_dev_access import AzureTableReplayLedger

    endpoint = os.environ["AUTH_SESSION_TABLE_ENDPOINT"]
    table = os.environ["AUTH_SESSION_TABLE_NAME"]
    stores = [AzureTableRecordStore(endpoint=endpoint, table_name=table, partition_key=partition)
              for partition in ("session", "flow", "session", "flow")]
    services = [SessionService(store=stores[index], flow_store=stores[index + 1], max_lifetime=timedelta(minutes=5))
                for index in (0, 2)]
    ledgers = [AzureTableReplayLedger(endpoint=os.environ["DEV_REPLAY_TABLE_ENDPOINT"],
               table_name=os.environ["DEV_REPLAY_TABLE_NAME"]) for _ in range(2)]
    expires = datetime.now(timezone.utc) + timedelta(minutes=5)
    try:
        flow = new_flow()
        await services[0].start_flow(flow, ttl=timedelta(minutes=5))
        claims = await asyncio.gather(*(service.claim_flow(flow.flow_id, flow.state) for service in services))
        assert sum(claim is not None for claim in claims) == 1
        assert await services[1].claim_flow(flow.flow_id, flow.state) is None
        identifier, _ = await services[0].create({"principal_id": "deployment-probe-not-a-user"}, token_expires_at=expires)
        assert await services[1].resolve(identifier) == {"principal_id": "deployment-probe-not-a-user"}
        await services[1].revoke(identifier)
        assert await services[0].resolve(identifier) is None
        replay = hashlib.sha256(uuid.uuid4().bytes).hexdigest()
        claimed = await asyncio.gather(*(ledger.claim(replay, expires) for ledger in ledgers))
        assert sorted(claimed) == [False, True]
        await ledgers[0].close()
        recreated = AzureTableReplayLedger(endpoint=os.environ["DEV_REPLAY_TABLE_ENDPOINT"], table_name=os.environ["DEV_REPLAY_TABLE_NAME"])
        try:
            assert await recreated.claim(replay, expires) is False
        finally:
            await recreated.close()
        return {"flow_atomic_consume": True, "session_cross_instance": True, "revocation": True,
                "replay_atomic": True, "replay_recreated_client_refusal": True,
                "human_signin": "not_verified", "replay_row": "retained until expiry; no early purge"}
    finally:
        for item in [*stores, *ledgers]:
            await item.close()


def private_probe():
    import urllib.error
    import urllib.request

    paths = ("/", "/api/health", "/assets/unknown", "/unknown")
    statuses = {}
    for path in paths:
        try:
            response = urllib.request.urlopen("http://127.0.0.1:8080" + path, timeout=15)
            status = response.status
            response.close()
        except urllib.error.HTTPError as error:
            status = error.code
        assert status == 401, (path, status)
        statuses[path] = status
    print(json.dumps({"status": "verified", "stage": "private-anonymous", "statuses": statuses}), flush=True)
    state = state_probe()
    print(json.dumps({"status": "verified", "stage": "cosmos-state", "result": state}), flush=True)
    tables = asyncio.run(table_probe())
    return {"anonymous": statuses, "state": state, "tables": tables}


def main():
    logging.disable(logging.CRITICAL)
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("private",))
    parser.parse_args()
    try:
        result = private_probe()
        print(json.dumps({"status": "verified", "observed_at": datetime.now(timezone.utc).isoformat(), **result}), flush=True)
    except Exception as error:
        print(json.dumps({"status": "failed", "error_type": type(error).__name__, "payload": "omitted"}), flush=True)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()