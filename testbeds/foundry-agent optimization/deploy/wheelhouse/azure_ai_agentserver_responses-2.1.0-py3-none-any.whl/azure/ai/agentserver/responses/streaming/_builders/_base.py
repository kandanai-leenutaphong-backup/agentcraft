# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.
"""Base builder infrastructure: lifecycle state, base class, and generic builder."""

from __future__ import annotations

from collections.abc import MutableMapping
from copy import deepcopy
from enum import Enum
from typing import TYPE_CHECKING, Any, cast

from ... import models as response_models

if TYPE_CHECKING:
    from .._event_stream import ResponseEventStream


def _require_non_empty(value: str, field_name: str) -> str:
    """Validate that a string value is non-empty.

    :param value: The string value to check.
    :type value: str
    :param field_name: The field name to include in the error message.
    :type field_name: str
    :returns: The validated non-empty string.
    :rtype: str
    :raises ValueError: If *value* is not a non-empty string.
    """
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string")
    return value


def _require_wire_dict(value: Any, field_name: str) -> dict[str, Any]:
    """Validate that a builder payload is already a dict-native wire payload.

    :param value: The value to validate.
    :type value: Any
    :param field_name: The field name to include in error messages.
    :type field_name: str
    :returns: The validated wire payload.
    :rtype: dict[str, Any]
    """
    if not isinstance(value, dict):
        raise TypeError(f"{field_name} must be a dict-native wire payload")
    return value


class BuilderLifecycleState(Enum):
    NOT_STARTED = "not_started"
    ADDED = "added"
    DONE = "done"


class BaseOutputItemBuilder:
    """Base output-item builder with lifecycle guards for added/done events."""

    def __init__(self, stream: "ResponseEventStream", output_index: int, item_id: str) -> None:
        """Initialize the base output-item builder.

        :param stream: The parent event stream to emit events into.
        :type stream: ResponseEventStream
        :param output_index: The zero-based index of this output item.
        :type output_index: int
        :param item_id: Unique identifier for this output item.
        :type item_id: str
        """
        self._stream = stream
        self._output_index = output_index
        self._item_id = item_id
        self._lifecycle_state = BuilderLifecycleState.NOT_STARTED
        self._internal_metadata: dict[str, Any] = {}

    @property
    def internal_metadata(self) -> MutableMapping[str, Any]:
        """Live, mutable framework-internal metadata for this output item.

        Read / write / delete in place (``message.internal_metadata["step"] = "n3"``).
        Whatever is set here is merged into the emitted ``output_item.added`` /
        ``output_item.done`` payloads under the item's ``internal_metadata`` key
        (and thus onto ``stream.response.output[i]``), and is stripped from every
        client-facing payload. Values may be any JSON-serialisable type.

        :rtype: ~collections.abc.MutableMapping[str, ~typing.Any]
        """
        return self._internal_metadata

    @internal_metadata.setter
    def internal_metadata(self, value: "MutableMapping[str, Any] | None") -> None:
        self._internal_metadata = dict(value) if value else {}

    def _stamp_internal_metadata(self, item: dict[str, Any]) -> dict[str, Any]:
        """Merge the builder's internal metadata into an item payload (if any).

        :param item: The output item dict being emitted.
        :type item: dict[str, Any]
        :returns: The item dict with ``internal_metadata`` merged in when non-empty.
        :rtype: dict[str, Any]
        """
        if self._internal_metadata:
            item = {**item, "internal_metadata": dict(self._internal_metadata)}
        return item

    @property
    def item_id(self) -> str:
        """Return the output item identifier.

        :returns: The item ID.
        :rtype: str
        """
        return self._item_id

    @property
    def output_index(self) -> int:
        """Return the zero-based output index.

        :returns: The output index.
        :rtype: int
        """
        return self._output_index

    def _ensure_transition(self, expected: BuilderLifecycleState, new_state: BuilderLifecycleState) -> None:
        """Guard a lifecycle state transition.

        :param expected: The expected current lifecycle state.
        :type expected: BuilderLifecycleState
        :param new_state: The target state to transition to.
        :type new_state: BuilderLifecycleState
        :rtype: None
        :raises ValueError: If the current state does not match *expected*.
        """
        if self._lifecycle_state is not expected:
            raise ValueError(
                "cannot transition to "
                f"'{new_state.value}' from '{self._lifecycle_state.value}' "
                f"(expected '{expected.value}')"
            )
        self._lifecycle_state = new_state

    def _emit_added(self, item: dict[str, Any]) -> response_models.ResponseOutputItemAddedEvent:
        """Emit an ``output_item.added`` event with lifecycle guard.

        :param item: The output item dict to include in the event.
        :type item: dict[str, Any]
        :returns: The emitted event.
        :rtype: ResponseOutputItemAddedEvent
        :raises ValueError: If the builder is not in ``NOT_STARTED`` state.
        """
        self._ensure_transition(BuilderLifecycleState.NOT_STARTED, BuilderLifecycleState.ADDED)
        item = self._stamp_internal_metadata(item)
        stamped_item = self._stream._with_output_item_defaults(item)  # pylint: disable=protected-access
        return cast(
            response_models.ResponseOutputItemAddedEvent,
            self._stream._emit_event(  # pylint: disable=protected-access
                {
                    "type": "response.output_item.added",
                    "output_index": self._output_index,
                    "item": stamped_item,
                }
            ),
        )

    def _emit_done(self, item: dict[str, Any]) -> response_models.ResponseOutputItemDoneEvent:
        """Emit an ``output_item.done`` event with lifecycle guard.

        :param item: The completed output item dict to include in the event.
        :type item: dict[str, Any]
        :returns: The emitted event.
        :rtype: ResponseOutputItemDoneEvent
        :raises ValueError: If the builder is not in ``ADDED`` state.
        """
        self._ensure_transition(BuilderLifecycleState.ADDED, BuilderLifecycleState.DONE)
        item = self._stamp_internal_metadata(item)
        stamped_item = self._stream._with_output_item_defaults(item)  # pylint: disable=protected-access
        return cast(
            response_models.ResponseOutputItemDoneEvent,
            self._stream._emit_event(  # pylint: disable=protected-access
                {
                    "type": "response.output_item.done",
                    "output_index": self._output_index,
                    "item": stamped_item,
                }
            ),
        )

    def _emit_item_state_event(
        self, event_type: str, *, extra_payload: dict[str, Any] | None = None
    ) -> response_models.ResponseStreamEvent:
        """Emit an item-level state event (e.g., in-progress, searching, completed).

        :param event_type: The event type string.
        :type event_type: str
        :keyword extra_payload: Optional additional fields to merge.
        :paramtype extra_payload: dict[str, Any] | None
        :returns: The emitted event.
        :rtype: ResponseStreamEvent
        """
        event: dict[str, Any] = {
            "type": event_type,
            "item_id": self._item_id,
            "output_index": self._output_index,
        }
        if extra_payload:
            event.update(deepcopy(extra_payload))
        return self._stream._emit_event(event)  # pylint: disable=protected-access


class OutputItemBuilder(BaseOutputItemBuilder):
    """Generic output-item builder for item types without dedicated scoped builders."""

    def __init__(
        self,
        stream: "ResponseEventStream",
        output_index: int,
        item_id: str,
        *,
        default_type: str | None = None,
    ) -> None:
        """Initialize a generic output-item builder.

        :param stream: The parent event stream to emit events into.
        :type stream: ResponseEventStream
        :param output_index: The zero-based index of this output item.
        :type output_index: int
        :param item_id: Unique identifier for this output item.
        :type item_id: str
        :keyword default_type: Optional discriminator to apply when an item omits ``type``.
        :paramtype default_type: str | None
        """
        super().__init__(stream, output_index, item_id)
        self._default_type = default_type

    def _with_default_type(self, item: dict[str, Any]) -> dict[str, Any]:
        if self._default_type is not None and "type" not in item:
            return {**item, "type": self._default_type}
        return item

    def emit_added(self, item: response_models.OutputItem) -> response_models.ResponseOutputItemAddedEvent:
        """Emit an ``output_item.added`` event for a generic item.

        :param item: The output item model instance.
        :type item: OutputItem
        :returns: The emitted event.
        :rtype: ResponseOutputItemAddedEvent
        """
        return self._emit_added(self._with_default_type(_require_wire_dict(item, "item")))

    def emit_done(self, item: response_models.OutputItem) -> response_models.ResponseOutputItemDoneEvent:
        """Emit an ``output_item.done`` event for a generic item.

        :param item: The completed output item model instance.
        :type item: OutputItem
        :returns: The emitted event.
        :rtype: ResponseOutputItemDoneEvent
        """
        return self._emit_done(self._with_default_type(_require_wire_dict(item, "item")))
