# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------

"""Configuration options for the Agent365 span exporter.

Defines the tunable settings—such as the ingestion endpoint, authentication
token resolvers, and payload size limits—used to construct an Agent365
exporter.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Optional

from microsoft.opentelemetry.a365.core.exporters.token_resolver_context import TokenResolverContext
from microsoft.opentelemetry.a365.core.exporters.utils import DEFAULT_MAX_PAYLOAD_BYTES


class Agent365ExporterOptions:
    """Configuration for Agent365Exporter.

    Either ``token_resolver`` or ``contextual_token_resolver`` must be set.
    When both are set, ``contextual_token_resolver`` takes precedence.
    """

    def __init__(
        self,
        cluster_category: str = "prod",
        token_resolver: Optional[Callable[[str, str], Optional[str]]] = None,
        contextual_token_resolver: Optional[Callable[[TokenResolverContext], Optional[str]]] = None,
        use_s2s_endpoint: bool = False,
        max_queue_size: int = 2048,
        scheduled_delay_ms: int = 5000,
        exporter_timeout_ms: int = 30000,
        max_export_batch_size: int = 512,
        max_payload_bytes: int = DEFAULT_MAX_PAYLOAD_BYTES,
        disable_offline_storage: bool = False,
        storage_directory: Optional[str] = None,
    ):
        """
        Args:
            cluster_category: Cluster region argument. Defaults to 'prod'.
            token_resolver: Callable(agent_id, tenant_id) -> token string or None.
                Either this or ``contextual_token_resolver`` must be set.
                When both are set, ``contextual_token_resolver`` takes precedence.
            contextual_token_resolver: Callable(TokenResolverContext) -> token string or None.
                Provides rich context including the agentic user ID.
                Takes precedence over ``token_resolver`` when set.
            use_s2s_endpoint: Use the S2S endpoint instead of standard endpoint.
            max_queue_size: Maximum queue size for the batch processor.
            scheduled_delay_ms: Delay between export batches (ms).
            exporter_timeout_ms: Timeout for the export operation (ms).
            max_export_batch_size: Maximum batch size for export operations.
            max_payload_bytes: Upper bound on HTTP request body size in bytes. The exporter
                splits per-identity batches into sub-batches whose estimated size stays under
                this limit, providing headroom under the A365 1 MB server limit. Default is
                900_000 (~100 KB headroom for estimator error and JSON envelope overhead).
            disable_offline_storage: When True, disables durable delivery (no disk writes or
                replay). Defaults to False (storage enabled).
            storage_directory: Custom directory for durable offline storage. When None, a
                platform default path is used. An explicitly empty or whitespace-only string
                is rejected with ``ValueError``. Defaults to None.

        Raises:
            ValueError: If ``storage_directory`` is an empty or whitespace-only string.
        """
        if storage_directory is not None and not str(storage_directory).strip():
            raise ValueError("storage_directory must be a non-empty path or None")
        self.cluster_category = cluster_category
        self.token_resolver = token_resolver
        self.contextual_token_resolver = contextual_token_resolver
        self.use_s2s_endpoint = use_s2s_endpoint
        self.max_queue_size = max_queue_size
        self.scheduled_delay_ms = scheduled_delay_ms
        self.exporter_timeout_ms = exporter_timeout_ms
        self.max_export_batch_size = max_export_batch_size
        self.max_payload_bytes = max_payload_bytes
        self.disable_offline_storage = disable_offline_storage
        self.storage_directory = storage_directory
